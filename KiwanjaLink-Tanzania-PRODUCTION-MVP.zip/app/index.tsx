import {router} from "expo-router";
import {Pressable,StyleSheet,Text,View} from "react-native";
export default function Home(){return <View style={s.c}>
<Text style={s.logo}>KiwanjaLink 🇹🇿</Text>
<Text style={s.h}>Pata kiwanja. Pata mpimaji. Fanya biashara kwa urahisi.</Text>
<Text style={s.p}>Soko la viwanja linalowaunganisha wanunuzi, wamiliki na wapimaji wa maeneo Tanzania.</Text>
<Pressable style={s.btn} onPress={()=>router.push("/auth")}><Text style={s.bt}>Ingia / Jisajili</Text></Pressable>
<Pressable onPress={()=>router.push("/listings")}><Text style={s.link}>Tazama viwanja bila kuingia</Text></Pressable>
</View>}
const s=StyleSheet.create({c:{flex:1,justifyContent:"center",padding:26,backgroundColor:"#F5F8F3"},logo:{fontSize:30,fontWeight:"900",marginBottom:28},h:{fontSize:28,fontWeight:"900",lineHeight:36},p:{fontSize:16,lineHeight:24,color:"#59615D",marginVertical:18},btn:{backgroundColor:"#176B3A",padding:17,borderRadius:14,alignItems:"center"},bt:{color:"#fff",fontWeight:"800"},link:{textAlign:"center",marginTop:20,color:"#176B3A",fontWeight:"700"}});
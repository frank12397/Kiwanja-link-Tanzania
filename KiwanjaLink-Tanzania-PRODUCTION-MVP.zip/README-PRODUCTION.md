# KiwanjaLink Tanzania — Production Blueprint

## Tayari kwenye code
- Google Maps screen + coordinates
- Listing photo picker UI
- Supabase storage bucket SQL
- Realtime chat foundation
- Admin verification screen
- EAS APK/AAB profiles
- Data model for owners, surveyors, listings, requests and messages

## API integrations to configure
### WhatsApp / SMS
Use a server-side provider such as WhatsApp Cloud API and an SMS provider. Credentials must live in Edge Functions/server environment, never in the mobile app.

### Tanzania payments
Create a server-side payment adapter for M-Pesa, Airtel Money and Mixx by Yas/Tigo Pesa through the chosen licensed payment gateway/aggregator. Keep provider secrets server-side and verify callbacks/webhooks before marking an order paid.

Recommended tables: payments, payment_events, notification_logs.

### Google Maps
Add the Android Maps API key through Expo/EAS secrets. Restrict the key to package `tz.kiwanjalink.app` and the required Maps APIs.

## Build AAB
1. `npm install`
2. `npm install -g eas-cli`
3. `eas login`
4. `eas build:configure`
5. `eas build --platform android --profile production`

The result is an Android App Bundle (.aab) for Google Play. An actual Play Store submission still requires your Google Play Console account, app signing, privacy policy, screenshots/icon, content declarations and the required developer information.

## Important
Do not put payment, WhatsApp, SMS, Google API secrets, Supabase service-role keys, or admin credentials in the mobile app.

# KiwanjaLink Tanzania — MVP iliyokamilishwa

## Inafanya
- Login / registration
- Buyer/owner/surveyor data model
- Kuchapisha viwanja
- Search ya viwanja
- Detail ya kiwanja
- Kuomba mpimaji/uhakiki
- Orodha ya wapimaji verified
- Ramani ya viwanja kwa coordinates
- Supabase RLS msingi
- Android APK/AAB configuration

## Setup
1. `npm install`
2. Tengeneza Supabase project.
3. Run `supabase/schema.sql` kwenye SQL Editor.
4. Copy `.env.example` kwenda `.env`, jaza Supabase keys.
5. `npx expo start`
6. Kwa APK: `npm install -g eas-cli`, `eas login`, `eas build --platform android --profile preview`
7. Kwa Play Store AAB: `eas build --platform android --profile production`

## Kabla ya production
- Google Maps API key/configuration
- Image upload + Supabase Storage
- Push notifications
- Realtime chat UI
- Admin verification panel
- Payment integration (M-Pesa/Airtel Money/Tigo Pesa)
- Privacy policy, terms, moderation
- Legal land/ownership verification process
- Google Play listing, screenshots, icon, privacy declarations

## Usalama
RLS imewekwa kwenye tables za msingi. Verification ya app isiwasilishe kama uthibitisho wa kisheria wa umiliki wa ardhi mpaka mchakato wa mamlaka/mtaalamu uthibitishwe.

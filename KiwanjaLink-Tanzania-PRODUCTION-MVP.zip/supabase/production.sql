-- Run after schema.sql.
-- Storage bucket for listing photos.
insert into storage.buckets(id,name,public) values('listing-photos','listing-photos',true) on conflict(id) do nothing;
create policy "listing photos public read" on storage.objects for select using(bucket_id='listing-photos');
create policy "listing owners upload" on storage.objects for insert with check(bucket_id='listing-photos' and auth.role()='authenticated');
-- Secure admin role checks in production should use a server-side role/custom claim,
-- not a client-editable profile field. Do NOT expose admin write policies to ordinary users.
